package com.guilherme.vitrine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VitrineApplicationTests {

	@Test
	void contextLoads() {
	}

}
